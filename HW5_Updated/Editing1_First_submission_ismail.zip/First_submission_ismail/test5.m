%
% Test the simplex solver.  This has an optimal solution with z=-464.7531.
%
load afiro.mat
epsilon1=1.0e-5;
epsilon2=1.0e-5;
epsilon3=1.0e-5;
[A,basis,nonbasis0,nonbasisu,c,u,m,n]= update_a_b_c_u(A,b,c,u);
[B,L,U,p,cb,cn0,cnu,ub,un0,unu,xb,y,rn0,rnu,z]=updateB(A,b,c,u,const,basis,nonbasis0,nonbasisu,epsilon2);
%
% Solve it.  
%
[xstar,optobj,optbasis,nonbasis0,nonbasisu,totaliters,ystar,wstar,zstar]=solvelp(A,b,c,u,const,[],100);
%
% Check the results
%
pfeas=norm(A*xstar-b)/norm(b)
cx=c'*xstar+const
optobj
dobj=ystar'*b-wstar'*u+const
dfeas=norm(ystar'*A-wstar'+zstar'-c')/norm(c)